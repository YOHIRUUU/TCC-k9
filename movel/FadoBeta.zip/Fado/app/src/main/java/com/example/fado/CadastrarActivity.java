package com.example.fado;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class CadastrarActivity extends AppCompatActivity {

    private EditText inputUser, inputEmail, inputSenha;
    private Switch switchAdmin;
    private Button botaoAcao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);

        // Ativa o menu dropdown na barra superior
        MenuHelper.configurarMenu(this, R.id.btnMenuDropdown);

        inputUser = findViewById(R.id.input_user);
        inputEmail = findViewById(R.id.input_email);
        inputSenha = findViewById(R.id.input_senha);
        switchAdmin = findViewById(R.id.switchAdmin);
        botaoAcao = findViewById(R.id.botao_acao);

        botaoAcao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = inputUser.getText().toString().trim();
                String email = inputEmail.getText().toString().trim();
                String senha = inputSenha.getText().toString().trim();
                boolean isAdmin = switchAdmin.isChecked();
                String opcao = isAdmin ? "1" : ""; // Envia "1" se admin estiver marcado, vazio se comum

                if (user.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(CadastrarActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                    return;
                }

                cadastrarUsuarioNoServidor(user, email, senha, opcao);
            }
        });
    }

    private void cadastrarUsuarioNoServidor(final String user, final String email, final String senha, final String opcao) {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/cadastrar";

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();

                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }

                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

                    String parametros = "user=" + user +
                            "&mail=" + email +
                            "&senha=" + senha +
                            "&opcao=" + opcao;

                    OutputStream os = conn.getOutputStream();
                    os.write(parametros.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                    os.close();

                    int codigoResposta = conn.getResponseCode();

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (codigoResposta >= 200 && codigoResposta < 300) {
                                Toast.makeText(CadastrarActivity.this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(CadastrarActivity.this, "Erro ao cadastrar usuário.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("DEBUG_FADO", "Erro no cadastro: ", e);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(CadastrarActivity.this, "Falha de conexão com o servidor.", Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}