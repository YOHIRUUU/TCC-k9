package com.example.fado;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

public class MainActivity extends AppCompatActivity {

    private EditText inputUser, inputEmail, inputSenha;
    private Button botaoAcao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referenciando os componentes do XML
        inputUser = findViewById(R.id.input_user);
        inputEmail = findViewById(R.id.input_email);
        inputSenha = findViewById(R.id.input_senha);
        botaoAcao = findViewById(R.id.botao_acao);

        // Ação do botão de entrar
        botaoAcao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usuario = inputUser.getText().toString().trim();
                String email = inputEmail.getText().toString().trim();
                String senha = inputSenha.getText().toString().trim();

                // Validação de campos obrigatórios no app
                if (usuario.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Envia os dados para o servidor em segundo plano
                enviarDadosParaFlask(email, usuario, senha);
            }
        });
    }

    private void enviarDadosParaFlask(String email, String user, String senha) {
        // Lendo a URL do servidor diretamente do arquivo XML (res/values/server_config.xml)
        final String urlServidor = getString(R.string.url_servidor);

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();

                    // EXCEÇÃO PARA HTTPS COM CERTIFICADO AUTOASSINADO (Ambiente de Debug/Desenvolvimento)
                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;

                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };

                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());

                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) {
                                return true; // Aceita o hostname do certificado autoassinado
                            }
                        });
                    }

                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json; utf-8");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);

                    // Criando o JSON para enviar
                    JSONObject jsonParam = new JSONObject();
                    jsonParam.put("mail", email);
                    jsonParam.put("user", user);
                    jsonParam.put("senha", senha);

                    Log.d("DEBUG_FADO", "Enviando para: " + urlServidor);

                    // Escrevendo os dados na requisição
                    try (OutputStream os = conn.getOutputStream()) {
                        byte[] input = jsonParam.toString().getBytes(StandardCharsets.UTF_8);
                        os.write(input, 0, input.length);
                    }

                    int codigoResposta = conn.getResponseCode();
                    Log.d("DEBUG_FADO", "Código de resposta HTTP: " + codigoResposta);

                    // Lendo a resposta do servidor Flask
                    BufferedReader br;
                    if (codigoResposta >= 200 && codigoResposta < 300) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    } else {
                        br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                    }

                    StringBuilder resposta = new StringBuilder();
                    String linha;
                    while ((linha = br.readLine()) != null) {
                        resposta.append(linha.trim());
                    }
                    br.close();

                    Log.d("DEBUG_FADO", "Resposta do Servidor: " + resposta.toString());

                    JSONObject jsonResposta = new JSONObject(resposta.toString());
                    boolean sucesso = jsonResposta.optBoolean("sucesso", false);

                    // Retorna para a thread principal da UI
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (sucesso) {
                                Toast.makeText(MainActivity.this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                                int permissaoServidor = jsonResposta.optInt("permisao", 0);
                                SessaoUsuario.getInstance().setPermissao(permissaoServidor);
                                Intent intent = new Intent(MainActivity.this, EstoqueActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                String mensagemErro = jsonResposta.optString("mensagem", "Erro ao fazer login.");
                                Toast.makeText(MainActivity.this, mensagemErro, Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("DEBUG_FADO", "Erro detalhado de conexão: ", e);
                    final String erroMsg = e.getMessage();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Erro de conexão: " + erroMsg, Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (conn != null) {
                        conn.disconnect();
                    }
                }
            }
        }).start();
    }
}