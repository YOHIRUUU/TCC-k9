package com.example.fado;

import android.app.Activity;
import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

public class MenuHelper {

    public static void configurarMenu(final Activity activity, int botaoId) {
        Button btnMenu = activity.findViewById(botaoId);
        if (btnMenu == null) return;

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(activity, v);

                // Adicionando as opções exigidas no menu
                popup.getMenu().add("Início / Estoque");
                popup.getMenu().add("Adicionar");
                popup.getMenu().add("Movimentação");
                popup.getMenu().add("Remover");
                popup.getMenu().add("Histórico");
                popup.getMenu().add("Cadastrar");
                popup.getMenu().add("Deslogar");

                int permissao = SessaoUsuario.getInstance().getPermissao();
                String nomeAtividade = activity.getClass().getSimpleName();

                // Regras de ocultação e bloqueio
                for (int i = 0; i < popup.getMenu().size(); i++) {
                    MenuItem item = popup.getMenu().getItem(i);
                    String titulo = item.getTitle().toString();

                    // 1. Ocultar a opção se o usuário já estiver na respectiva tela
                    if (nomeAtividade.equals("EstoqueActivity") && titulo.equals("Início / Estoque")) {
                        item.setVisible(false);
                    } else if (nomeAtividade.equals("AdicionarActivity") && titulo.equals("Adicionar")) {
                        item.setVisible(false);
                    } else if (nomeAtividade.equals("MovimentoActivity") && titulo.equals("Movimentação")) {
                        item.setVisible(false);
                    } else if (nomeAtividade.equals("RemoverActivity") && titulo.equals("Remover")) {
                        item.setVisible(false);
                    } else if (nomeAtividade.equals("HistoricoActivity") && titulo.equals("Histórico")) {
                        item.setVisible(false);
                    } else if (nomeAtividade.equals("CadastrarActivity") && titulo.equals("Cadastrar")) {
                        item.setVisible(false);
                    }

                    // 2. Bloquear (desativar) Adicionar, Remover e Cadastrar para não administradores (permissão 0)
                    if (permissao == 0 && (titulo.equals("Adicionar") || titulo.equals("Remover") || titulo.equals("Cadastrar"))) {
                        item.setEnabled(false);
                        item.setTitle(titulo + " (Admin)");
                    }
                }

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        String opcao = item.getTitle().toString();
                        int permissaoAtual = SessaoUsuario.getInstance().getPermissao();

                        // Verificação de segurança caso cliquem em opções restritas
                        if ((opcao.contains("Adicionar") || opcao.contains("Remover") || opcao.contains("Cadastrar")) && permissaoAtual == 0) {
                            Toast.makeText(activity, "Acesso restrito a administradores!", Toast.LENGTH_SHORT).show();
                            return true;
                        }

                        Intent intent = null;

                        // Corrigido para verificar "Início / Estoque" corretamente
                        if (opcao.equals("Início / Estoque")) {
                            intent = new Intent(activity, EstoqueActivity.class);
                        } else if (opcao.startsWith("Adicionar")) {
                            intent = new Intent(activity, AdicionarActivity.class);
                        } else if (opcao.startsWith("Movimentação")) {
                            intent = new Intent(activity, MovimentoActivity.class);
                        } else if (opcao.startsWith("Remover")) {
                            intent = new Intent(activity, RemoverActivity.class);
                        } else if (opcao.startsWith("Histórico")) {
                            intent = new Intent(activity, HistoricoActivity.class);
                        } else if (opcao.startsWith("Cadastrar")) {
                            intent = new Intent(activity, CadastrarActivity.class);
                        } else if (opcao.equals("Deslogar")) {
                            intent = new Intent(activity, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        }

                        if (intent != null) {
                            activity.startActivity(intent);
                        }
                        return true;
                    }
                });

                popup.show();
            }
        });
    }
}