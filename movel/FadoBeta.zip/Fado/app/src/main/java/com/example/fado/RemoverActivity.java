package com.example.fado;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class RemoverActivity extends AppCompatActivity {

    private Spinner spinnerProdutosRemover;
    private Button btnConfirmarRemocao;

    private ArrayList<MovimentoActivity.ItemProduto> listaItensSpinner = new ArrayList<>();
    private ArrayAdapter<MovimentoActivity.ItemProduto> spinnerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remover);

        MenuHelper.configurarMenu(this, R.id.btnMenuDropdown);

        spinnerProdutosRemover = findViewById(R.id.spinnerProdutosRemover);
        btnConfirmarRemocao = findViewById(R.id.btnConfirmarRemocao);

        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaItensSpinner);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProdutosRemover.setAdapter(spinnerAdapter);

        carregarProdutosParaSpinner();

        btnConfirmarRemocao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listaItensSpinner.isEmpty()) {
                    Toast.makeText(RemoverActivity.this, "Nenhum produto disponível.", Toast.LENGTH_SHORT).show();
                    return;
                }

                MovimentoActivity.ItemProduto produtoSelecionado = (MovimentoActivity.ItemProduto) spinnerProdutosRemover.getSelectedItem();
                removerProdutoNoServidor(String.valueOf(produtoSelecionado.getId()));
            }
        });
    }

    private void carregarProdutosParaSpinner() {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/estoque";

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();

                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }

                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");

                    int codigoResposta = conn.getResponseCode();
                    if (codigoResposta >= 200 && codigoResposta < 300) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                        StringBuilder resposta = new StringBuilder();
                        String linha;
                        while ((linha = br.readLine()) != null) {
                            resposta.append(linha.trim());
                        }
                        br.close();

                        JSONObject jsonResposta = new JSONObject(resposta.toString());
                        JSONArray registros = jsonResposta.getJSONArray("registros");

                        listaItensSpinner.clear();
                        for (int i = 0; i < registros.length(); i++) {
                            JSONObject item = registros.getJSONObject(i);
                            int id = item.optInt("id");
                            String nome = item.optString("nome");
                            listaItensSpinner.add(new MovimentoActivity.ItemProduto(id, nome));
                        }

                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                spinnerAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                } catch (Exception e) {
                    Log.e("DEBUG_FADO", "Erro ao carregar produtos para o Spinner de remoção: ", e);
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }

    private void removerProdutoNoServidor(final String idItem) {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/remover";

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();

                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }

                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

                    String parametros = "item_selecionado=" + idItem;

                    OutputStream os = conn.getOutputStream();
                    os.write(parametros.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                    os.close();

                    int codigoResposta = conn.getResponseCode();

                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (codigoResposta >= 200 && codigoResposta < 300) {
                                Toast.makeText(RemoverActivity.this, "Produto removido com sucesso!", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(RemoverActivity.this, "Erro ao remover produto.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });

                } catch (Exception e) {
                    Log.e("DEBUG_FADO", "Erro na remoção: ", e);
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(RemoverActivity.this, "Falha de conexão.", Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}