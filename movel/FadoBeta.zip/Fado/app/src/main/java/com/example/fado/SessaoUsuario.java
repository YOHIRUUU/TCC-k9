package com.example.fado;

public class SessaoUsuario {
    private static SessaoUsuario instancia;
    private int permissao = 0; // 0 = comum, 1 = administrador
    private String email = ""; // Armazena o email do usuário logado

    private SessaoUsuario() {}

    public static synchronized SessaoUsuario getInstance() {
        if (instancia == null) {
            instancia = new SessaoUsuario();
        }
        return instancia;
    }

    public void setPermissao(int permissao) {
        this.permissao = permissao;
    }

    public int getPermissao() {
        return permissao;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}