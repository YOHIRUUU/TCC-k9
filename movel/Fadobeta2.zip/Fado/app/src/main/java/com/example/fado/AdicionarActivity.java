package com.example.fado;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AdicionarActivity extends AppCompatActivity {
    private EditText editNome, editQuantidade, editPreco, editCategoria, editDescricao, editImagem;
    private Button btnCadastrarProduto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar);
        MenuHelper.configurarMenu(this, R.id.btnMenuDropdown);
        editNome = findViewById(R.id.editNome);
        editQuantidade = findViewById(R.id.editQuantidade);
        editPreco = findViewById(R.id.editPreco);
        editCategoria = findViewById(R.id.editCategoria);
        editDescricao = findViewById(R.id.editDescricao);
        editImagem = findViewById(R.id.editImagem);
        btnCadastrarProduto = findViewById(R.id.btnCadastrarProduto);
        btnCadastrarProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = editNome.getText().toString().trim();
                String quantidade = editQuantidade.getText().toString().trim();
                String preco = editPreco.getText().toString().trim();
                String categoria = editCategoria.getText().toString().trim();
                String descricao = editDescricao.getText().toString().trim();
                String imagem = editImagem.getText().toString().trim();
                if (nome.isEmpty() || quantidade.isEmpty()) {
                    Toast.makeText(AdicionarActivity.this, "Preencha ao menos Nome e Quantidade!", Toast.LENGTH_SHORT).show();
                    return;
                }
                adicionarProdutoNoServidor(nome, quantidade, preco, categoria, descricao, imagem);
            }
        });
    }

    private void adicionarProdutoNoServidor(final String nome, final String quantidade, final String preco, final String categoria, final String descricao, final String imagem) {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/adicionar";
        final String emailUsuario = SessaoUsuario.getInstance().getEmail();
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();
                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    String parametros = "Nome=" + nome +
                            "&Quantidade=" + quantidade +
                            "&Preco=" + preco +
                            "&Categoria=" + categoria +
                            "&Descricao=" + descricao +
                            "&Imagem=" + imagem +
                            "&email=" + emailUsuario;
                    OutputStream os = conn.getOutputStream();
                    os.write(parametros.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                    os.close();
                    int codigoResposta = conn.getResponseCode();
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (codigoResposta >= 200 && codigoResposta < 300) {
                                Toast.makeText(AdicionarActivity.this, "Produto adicionado com sucesso!", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(AdicionarActivity.this, "Erro ao adicionar produto.", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                } catch (Exception e) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(AdicionarActivity.this, "Falha de conexão.", Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}