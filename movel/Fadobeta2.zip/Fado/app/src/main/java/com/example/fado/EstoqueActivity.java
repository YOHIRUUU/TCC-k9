package com.example.fado;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class EstoqueActivity extends AppCompatActivity {
    private ListView listViewEstoque;
    private ArrayList<Produto> listaProdutos;
    private ProdutoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estoque);
        MenuHelper.configurarMenu(this, R.id.btnMenuDropdown);
        listViewEstoque = findViewById(R.id.listViewEstoque);
        listaProdutos = new ArrayList<>();
        adapter = new ProdutoAdapter();
        listViewEstoque.setAdapter(adapter);
        carregarEstoqueDoServidor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarEstoqueDoServidor();
    }

    public static class Produto {
        String nome, categoria, descricao, imagem;
        int id, quantidade;
        double preco;

        public Produto(int id, String nome, int quantidade, double preco, String categoria, String descricao, String imagem) {
            this.id = id;
            this.nome = nome;
            this.quantidade = quantidade;
            this.preco = preco;
            this.categoria = categoria;
            this.descricao = descricao;
            this.imagem = imagem;
        }
    }

    private class ProdutoAdapter extends BaseAdapter {
        @Override
        public int getCount() { return listaProdutos.size(); }
        @Override
        public Object getItem(int position) { return listaProdutos.get(position); }
        @Override
        public long getItemId(int position) { return listaProdutos.get(position).id; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(EstoqueActivity.this).inflate(R.layout.item_estoque, parent, false);
            }
            Produto p = listaProdutos.get(position);
            TextView txtNome = convertView.findViewById(R.id.txtNomeProduto);
            TextView txtPreco = convertView.findViewById(R.id.txtPrecoProduto);
            TextView txtCategoria = convertView.findViewById(R.id.txtCategoria);
            TextView txtQtd = convertView.findViewById(R.id.txtQuantidade);
            TextView txtDescricao = convertView.findViewById(R.id.txtDescricao);
            txtNome.setText(p.nome);
            txtPreco.setText(String.format("R$ %.2f", p.preco));
            txtCategoria.setText("Categoria: " + p.categoria);
            txtQtd.setText("Qtd: " + p.quantidade);
            txtDescricao.setText(p.descricao != null && !p.descricao.isEmpty() ? p.descricao : "Sem descrição");
            return convertView;
        }
    }

    private void carregarEstoqueDoServidor() {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/estoque";
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();
                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    int codigoResposta = conn.getResponseCode();
                    BufferedReader br;
                    if (codigoResposta >= 200 && codigoResposta < 300) {
                        br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    } else {
                        br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                    }
                    StringBuilder resposta = new StringBuilder();
                    String linha;
                    while ((linha = br.readLine()) != null) {
                        resposta.append(linha.trim());
                    }
                    br.close();
                    JSONObject jsonResposta = new JSONObject(resposta.toString());
                    JSONArray registros = jsonResposta.getJSONArray("registros");
                    listaProdutos.clear();
                    for (int i = 0; i < registros.length(); i++) {
                        JSONObject item = registros.getJSONObject(i);
                        listaProdutos.add(new Produto(
                                item.optInt("id"),
                                item.optString("nome"),
                                item.optInt("quantidade"),
                                item.optDouble("preco"),
                                item.optString("categoria"),
                                item.optString("descricao"),
                                item.optString("imagem")
                        ));
                    }
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                } catch (Exception e) {
                    mostrarErro("Falha de conexão: " + e.getMessage());
                } finally {
                    if (conn != null) {
                        conn.disconnect();
                    }
                }
            }
        }).start();
    }

    private void mostrarErro(String mensagem) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(EstoqueActivity.this, mensagem, Toast.LENGTH_LONG).show();
            }
        });
    }
}