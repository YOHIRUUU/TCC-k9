package com.example.fado;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class HistoricoActivity extends AppCompatActivity {
    private ListView listViewHistorico;
    private ArrayList<LogHistorico> listaHistorico;
    private HistoricoAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico);
        MenuHelper.configurarMenu(this, R.id.btnMenuDropdown);
        listViewHistorico = findViewById(R.id.listViewHistorico);
        listaHistorico = new ArrayList<>();
        adapter = new HistoricoAdapter();
        listViewHistorico.setAdapter(adapter);
        carregarHistoricoDoServidor();
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarHistoricoDoServidor();
    }

    public static class LogHistorico {
        int idLog, qtdAnterior, qtdNova;
        String acao, produtoNome, dataHora, email;

        public LogHistorico(int idLog, String acao, String produtoNome, int qtdAnterior, int qtdNova, String dataHora, String email) {
            this.idLog = idLog;
            this.acao = acao;
            this.produtoNome = produtoNome;
            this.qtdAnterior = qtdAnterior;
            this.qtdNova = qtdNova;
            this.dataHora = dataHora;
            this.email = email;
        }
    }

    private class HistoricoAdapter extends BaseAdapter {
        @Override
        public int getCount() { return listaHistorico.size(); }
        @Override
        public Object getItem(int position) { return listaHistorico.get(position); }
        @Override
        public long getItemId(int position) { return listaHistorico.get(position).idLog; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(HistoricoActivity.this).inflate(R.layout.item_historico, parent, false);
            }
            LogHistorico log = listaHistorico.get(position);
            TextView txtAcaoProduto = convertView.findViewById(R.id.txtAcaoProduto);
            TextView txtQuantidades = convertView.findViewById(R.id.txtQuantidades);
            TextView txtEmailData = convertView.findViewById(R.id.txtEmailData);
            txtAcaoProduto.setText(log.acao + " - " + log.produtoNome);
            txtQuantidades.setText("Anterior: " + log.qtdAnterior + "  ➔  Nova Qtd: " + log.qtdNova);
            String emailExibicao = (log.email != null && !log.email.isEmpty()) ? log.email : "Desconhecido";
            txtEmailData.setText("Por: " + emailExibicao + " | " + log.dataHora);
            return convertView;
        }
    }

    private void carregarHistoricoDoServidor() {
        final String urlBase = getString(R.string.url_servidor).replace("/api/login", "");
        final String urlServidor = urlBase + "/api/historico";
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(urlServidor);
                    conn = (HttpURLConnection) url.openConnection();
                    if (conn instanceof HttpsURLConnection) {
                        HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() { return null; }
                                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                                }
                        };
                        SSLContext sc = SSLContext.getInstance("TLS");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        httpsConn.setSSLSocketFactory(sc.getSocketFactory());
                        httpsConn.setHostnameVerifier(new HostnameVerifier() {
                            public boolean verify(String hostname, SSLSession session) { return true; }
                        });
                    }
                    conn.setRequestMethod("GET");
                    conn.setRequestProperty("Accept", "application/json");
                    int codigoResposta = conn.getResponseCode();
                    if (codigoResposta >= 200 && codigoResposta < 300) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                        StringBuilder resposta = new StringBuilder();
                        String linha;
                        while ((linha = br.readLine()) != null) {
                            resposta.append(linha.trim());
                        }
                        br.close();
                        JSONObject jsonResposta = new JSONObject(resposta.toString());
                        JSONArray registros = jsonResposta.getJSONArray("registros");
                        listaHistorico.clear();
                        for (int i = 0; i < registros.length(); i++) {
                            JSONObject item = registros.getJSONObject(i);
                            listaHistorico.add(new LogHistorico(
                                    item.optInt("id_log"),
                                    item.optString("acao"),
                                    item.optString("produto_nome"),
                                    item.optInt("qtd_anterior"),
                                    item.optInt("qtd_nova"),
                                    item.optString("data_hora"),
                                    item.optString("email")
                            ));
                        }
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                adapter.notifyDataSetChanged();
                            }
                        });
                    }
                } catch (Exception e) {
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}