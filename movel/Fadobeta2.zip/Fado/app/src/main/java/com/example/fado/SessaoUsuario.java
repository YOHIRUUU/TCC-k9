package com.example.fado;

public class SessaoUsuario {
    private static SessaoUsuario instancia;
    private int permissao = 0;
    private String email = "";

    private SessaoUsuario() {}

    public static synchronized SessaoUsuario getInstance() {
        if (instancia == null) {
            instancia = new SessaoUsuario();
        }
        return instancia;
    }

    public void setPermissao(int permissao) {
        this.permissao = permissao;
    }

    public int getPermissao() {
        return permissao;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}